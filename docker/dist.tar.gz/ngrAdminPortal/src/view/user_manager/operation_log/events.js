import { EventEmitter } from '../../../util/eventBus';

export const eventBus = new EventEmitter();